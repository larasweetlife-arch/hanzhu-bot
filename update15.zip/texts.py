"""Тексты интерфейса на четырёх языках."""

LANG_PROMPT = "Выбери язык 🇷🇺\nTilni tanlang 🇺🇿\nChoose language 🇬🇧\n选择语言 🇨🇳"

WEEKDAYS = {
    "ru": ["пн", "вт", "ср", "чт", "пт", "сб", "вс"],
    "uz": ["du", "se", "ch", "pa", "ju", "sh", "ya"],
    "en": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    "zh": ["周一", "周二", "周三", "周四", "周五", "周六", "周日"],
}

T = {
"ru": {
 "b_grammar": "📐 Грамматика",
 "b_texts": "📖 Тексты",
 "b_adult": "🔞 Ругательства 16+",
 "ru_only": "",
 "gr_title": "📐 <b>Грамматика HSK {lvl}</b> · {n} из {total}",
 "gr_fallback": "Для твоего уровня грамматики пока нет, показываю самый высокий из имеющихся: HSK {lvl}.",
 "gr_formula": "Формула",
 "tx_adapted": "Адаптированный текст",
 "tx_classic": "Классика",
 "tx_title": "📖 <b>{kind}</b> · {lvl} · {n} из {total}",
 "tx_lvl_any": "любой уровень",
 "tx_translation": "Перевод",
 "tx_empty": "Для этого раздела текстов пока нет.",
 "adult_head": "🔞 <b>Грубая лексика 16+</b>",
 "adult_gate": "🔞 <b>Раздел 16+</b>\n\nЗдесь грубая лексика и ругательства: чтобы понимать, что говорят в сериалах и на улице, а не чтобы использовать.\n\nТебе уже есть 16 лет?",
 "adult_yes": "Да, мне есть 16",
 "adult_no": "Нет",
 "adult_declined": "Хорошо, тогда в другой раз 🙂",
 "adult_closed": "Этот раздел для тебя закрыт.",
 "adult_more": "➡️ Ещё",
 "adult_lv1": "🟡 грубовато",
 "adult_lv2": "🟠 грубо",
 "adult_lv3": "🔴 очень грубо",
 "adult_rude": "Грубость",
 "adult_foot": "⚠️ Чтобы понимать, а не использовать: в вежливой речи так говорить нельзя.",
 "slang_label": "🔥 Интернет-сленг",
 "bkrs_more": "🔎 Подробнее по-русски: <a href=\"{url}\">БКРС</a>",
 "bkrs_btn": "🔎 Искать в БКРС",
 "greet": "🍵 <b>Привет-привет!</b>\n\nМеня зовут <b>茶茶 (ЧаЧа)</b>, я маленький чайный дух 🌿\nЖиву в чашке-гайвань, а работаю помощником Лазизы по китайскому ✨\n\n<i>Налью тебе немного китайского: без спешки и без зубрёжки</i> 🫖\n\nДавай знакомиться! Как тебя зовут?",
 "features": "Вот чем я могу быть полезен:\n\n📚 <b>Слово дня</b>\n🧧 <b>Чэнъюй</b>\n🌏 <b>Факты о Китае</b>, когда хочется чего-то небольшого и интересного\n🔤 <b>Перевод</b> на китайский и обратно, с пиньинем\n📊 <b>Прогресс</b>, если занимаешься с Лазизой: уроки, оплата, результаты тестов\n🗓 <b>Напоминания</b> о занятиях\n\nНе нашёл(ла), что нужно? Просто напиши мне, я передам Лазизе, и она ответит сама 💌\n\nМеню внизу, начинай с чего угодно 👇\n<i>Как я обращаюсь с данными: /privacy</i>",
 "about_head": "🍵 <b>茶茶 (ЧаЧа)</b> · 汉助 Bot\nЧайный помощник по китайскому",
 "privacy": "🔒 <b>Конфиденциальность</b>\n\nЯ храню только то, что нужно, чтобы бот работал:\n· твой Telegram ID и @username\n· имя, язык, уровень и откуда ты узнал(а) обо мне\n· если ты ученик: количество проведённых и оплаченных уроков, расписание, результаты тестов, подтверждения и отмены занятий с причинами\n· какими кнопками бота ты пользуешься (просто счётчик, без текста)\n· какие слова, чэнъюй и факты я тебе уже показывал, чтобы не повторяться\n· отметку, что ты подтвердил(а) возраст 16+ (если открывал(а) раздел 16+)\n· слова из «Перевода», которых не нашлось в словаре (текст запроса без привязки к тебе)\n\nТвои сообщения мне бот в своей базе не хранит, они только пересылаются Лазизе.\n\nДоступ к данным есть только у Лазизы. Я не продаю их и не передаю рекламным сервисам. Они лежат на сервере, где работает бот, а раз в неделю копия базы отправляется Лазизе в Telegram.\n\n<b>Твои права</b>\n· получить копию своих данных: /mydata\n· удалить всё: /deletemydata (кроме того, что закон обязывает хранить, если такое требование есть)\n· исправить данные, ограничить их обработку, возразить против неё или отозвать согласие: напиши Лазизе через бота\n· подать жалобу в орган по защите персональных данных своей страны, если считаешь, что твои права не соблюдаются\n\nЕсли ученик несовершеннолетний, всё это может сделать родитель, написав Лазизе через бота.\n\nОбновлено: октябрь 2026. Изменения публикуются здесь, в /privacy.",
 "mydata_caption": "📄 Копия всех данных, которые бот хранит о тебе.",
 "mydata_empty": "Пока у меня нет твоих данных.",
 "del_ask": "Удалить все твои данные из бота: профиль, уроки, оплаты, результаты тестов, расписание? Это нельзя отменить.",
 "btn_del_yes": "🗑 Да, удалить",
 "btn_del_no": "Отмена",
 "del_done": "Готово, всё удалено. Если захочешь вернуться, нажми /start 🍵",
 "del_cancel": "Хорошо, ничего не удалила.",
 "ask_source": "Приятно познакомиться, {name}!\n\nОткуда ты про меня узнал(а)?",
 "ask_level": "И последнее: какой у тебя уровень китайского?",
 "done": "Готово, {name}! Добро пожаловать 🐉",
 "menu": "Что делаем?",
 "hi": "你好 (nǐ hǎo — привет)",
 "welcome_back": "{hi}, {name}! 🐉\nЯ 茶茶 (ЧаЧа), чайный помощник по китайскому. Рад, что ты снова здесь 🍵\n\nВот что я умею:\n📚 слово дня и 🧧 чэнъюй\n🌏 факты о Китае\n🔤 перевод с пиньинем\n📐 грамматика и 📖 тексты по уровням\n📊 прогресс и 🗓 напоминания о занятиях, если ты занимаешься с Лазизой\n\nНе нашёл(ла), что нужно? Просто напиши мне, я передам Лазизе 💌\n\nВыбирай в меню внизу 👇",
 "b_sched": "🗓 Занятия",
 "sch_title": "🗓 <b>Мои занятия</b>",
 "sch_days": "Расписание",
 "sch_next": "Ближайшее занятие",
 "sch_today": "сегодня", "sch_tomorrow": "завтра",
 "sch_remind": "🔔 Напомню о занятии за сутки и за час до начала.",
 "sch_empty": "Расписание пока не задано. Лазиза добавит его, и я начну напоминать 🔔",
 "sch_guest": "Напоминания о занятиях приходят ученикам Лазизы 🔔 Если ты уже занимаешься с ней, просто напиши мне сюда, я передам, и она добавит тебя в список.",
 "student_welcome": "🎓 Ты теперь в списке учеников Лазизы! Здесь будут твой прогресс и напоминания о занятиях.",
 "sources": ["Канал «Чаёвничаем о китайском»", "От друга", "Из группы или чата", "Занимаюсь с Лазизой", "Другое"],
 "levels": ["Только начинаю", "HSK 1", "HSK 2", "HSK 3", "HSK 4", "HSK 5", "HSK 6", "HSK 7–9"],
 "b_word": "📚 Слово дня", "b_chengyu": "🧧 Чэнъюй", "b_fact": "🌏 Факт о Китае",
 "b_tr": "🔤 Перевод", "b_progress": "📊 Мой прогресс", "b_lang": "🌐 Язык",
 "b_channel": "📢 Канал", "b_help": "❓ Помощь",
 "word": "📚 Слово дня", "chengyu": "🧧 Чэнъюй дня", "fact": "🌏 Факт о Китае",
 "tr_ask": "Напиши слово, на русском или на китайском:",
 "tr_none": "Не нашёл «{q}» 🔄\nПопробуй слово по-китайски или по-английски. Я записал запрос, словарь будет пополняться.",
 "tr_en_note": "Значения пока на английском: русский и узбекский словарь я ещё наполняю.",
 "tr_split": "Разбор по словам:",
 "channel": "📢 Мой канал о китайском языке и культуре:\nhttps://t.me/qing_laoshi",
 "help": ("汉助, помощник по китайскому\nСоздан Лазизой Ропижоновой\n\n"
          "/menu меню\n/word слово дня\n/chengyu чэнъюй\n/fact факт о Китае\n"
          "/translate перевод\n/progress мой прогресс\n/lang сменить язык\n/about что я умею\n/privacy конфиденциальность\n/mydata копия моих данных\n/deletemydata удалить мои данные\n\n"
          "Если напишешь мне что-то своё, я передам это Лазизе, и она ответит сама."),
 "no_progress": ("Пока тут пусто 🌱\n\nЭтот раздел заполняется, когда ты занимаешься с Лазизой: "
                 "видно пройденные уроки, оплату и результаты тестов.\n\n"
                 "Хочешь заниматься, напиши ей, первый урок бесплатный."),
 "p_title": "📊 Твой прогресс", "p_lessons": "Уроков пройдено", "p_paid": "Оплачено",
 "p_left": "Осталось", "p_renew": "Пора продлить занятия, напиши Лазизе",
 "p_tests": "📈 Результаты тестов", "p_first": "Первый", "p_last": "Последний",
 "p_growth": "Динамика", "p_pp": "п.п.", "p_no_tests": "Тестов пока не было.",
 "p_recent": "🗓 Последние занятия", "p_sched": "Расписание",
 "lang_pick": "Выбери язык общения", "lang_changed": "Готово, общаемся по-русски 🐉",
 "day_today": "сегодня", "day_tomorrow": "завтра",
 "remind24": "🗓 Занятие {day} в <b>{time}</b>.\nВсё в силе?",
 "remind1": "⏰ Через час занятие ({time}).", "remind1_link": "\n\nСсылка: {link}",
 "btn_yes": "✅ Буду", "btn_no": "❌ Не смогу",
 "att_yes": "Отлично, жду 🐉",
 "att_ask": "Жаль 😔 Напиши одним сообщением причину, я передам Лазизе.",
 "att_ok": "Передала Лазизе, она свяжется насчёт переноса 🤍",
 "att_late": "Передала Лазизе, она свяжется 🤍\nНапоминаю: по условиям отмена позже чем за 3 часа считается проведённым уроком.",
 "att_past": "Это занятие уже прошло.",
 "pay_nudge": "Привет! Оплаченные занятия подходят к концу. Когда будет удобно, напиши Лазизе насчёт продления 🤍",
 "q_sent": "Передала твоё сообщение Лазизе, она ответит сама 🤍",
},
"uz": {
 "b_grammar": "📐 Qoidalar",
 "b_texts": "📖 Matnlar",
 "b_adult": "🔞 So'kinishlar 16+",
 "ru_only": "Hozircha faqat rus tilida.",
 "gr_title": "📐 <b>HSK {lvl} grammatikasi</b> · {n} / {total}",
 "gr_fallback": "Sizning darajangiz uchun grammatika hali yo'q, mavjud eng yuqorisini ko'rsatyapman: HSK {lvl}.",
 "gr_formula": "Formula",
 "tx_adapted": "Moslashtirilgan matn",
 "tx_classic": "Klassika",
 "tx_title": "📖 <b>{kind}</b> · {lvl} · {n} / {total}",
 "tx_lvl_any": "har qanday daraja",
 "tx_translation": "Tarjima",
 "tx_empty": "Bu bo'lim uchun matnlar hali yo'q.",
 "adult_head": "🔞 <b>Qo'pol so'zlar 16+</b>",
 "adult_gate": "🔞 <b>16+ bo'limi</b>\n\nBu yerda qo'pol so'zlar va so'kinishlar: seriallarda va ko'chada nima deyilayotganini tushunish uchun, ishlatish uchun emas.\n\nSiz 16 yoshdan oshganmisiz?",
 "adult_yes": "Ha, 16 yoshdan oshganman",
 "adult_no": "Yo'q",
 "adult_declined": "Mayli, boshqa safar 🙂",
 "adult_closed": "Bu bo'lim siz uchun yopiq.",
 "adult_more": "➡️ Yana",
 "adult_lv1": "🟡 biroz qo'pol",
 "adult_lv2": "🟠 qo'pol",
 "adult_lv3": "🔴 juda qo'pol",
 "adult_rude": "Qo'polligi",
 "adult_foot": "⚠️ Tushunish uchun, ishlatish uchun emas: odobli suhbatda bunday gapirib bo'lmaydi.",
 "slang_label": "🔥 Internet slengi",
 "bkrs_more": "🔎 Ruscha batafsil: <a href=\"{url}\">BKRS</a>",
 "bkrs_btn": "🔎 BKRS'da qidirish",
 "greet": "🍵 <b>Salom-salom!</b>\n\nMening ismim <b>茶茶 (ChaCha)</b>, men kichkina choy ruhiman 🌿\nGaywan piyolada yashayman, Lazizaning xitoy tili yordamchisi bo'lib ishlayman ✨\n\n<i>Sizga ozgina xitoy tilini quyib beraman: shoshilmasdan va yodlamasdan</i> 🫖\n\nKeling, tanishamiz! Ismingiz nima?",
 "features": "Mana nimalarga qodirman:\n\n📚 <b>Kunning so'zi</b>\n🧧 <b>Chengyu</b>\n🌏 <b>Xitoy haqida faktlar</b>, kichkina va qiziq narsa kerak bo'lganda\n🔤 <b>Tarjima</b> xitoychaga va orqaga, pinyin bilan\n📊 <b>Natijam</b>, Laziza bilan shug'ullansangiz: darslar, to'lov, test natijalari\n🗓 Darslar haqida <b>eslatmalar</b>\n\nKerakli narsani topolmadingizmi? Shunchaki yozing, Lazizaga yetkazaman, u o'zi javob beradi 💌\n\nMenyu pastda, istalgan joydan boshlang 👇\n<i>Ma'lumotlar bilan qanday ishlayman: /privacy</i>",
 "about_head": "🍵 <b>茶茶 (ChaCha)</b> · 汉助 Bot\nXitoy tili bo'yicha choy yordamchisi",
 "privacy": "🔒 <b>Maxfiylik</b>\n\nFaqat bot ishlashi uchun kerakli narsalarni saqlayman:\n· Telegram ID va @username\n· ism, til, daraja va men haqimda qayerdan bilganingiz\n· agar o'quvchi bo'lsangiz: o'tilgan va to'langan darslar soni, jadval, test natijalari, darslarni tasdiqlash va bekor qilish (sabablari bilan)\n· bot tugmalaridan qaysi birini ishlatganingiz (faqat hisob, matnsiz)\n· qaysi so'z, chengyu va faktlarni sizga ko'rsatganim, takrorlanmaslik uchun\n· 16+ bo'limini ochgan bo'lsangiz, 16 yoshdan oshganingizni tasdiqlaganingiz haqida belgi\n· «Tarjima»da lug'atdan topilmagan so'zlar (so'rov matni, sizga bog'lanmagan holda)\n\nMenga yozgan xabarlaringizni bot o'z bazasida saqlamaydi, ular faqat Lazizaga yuboriladi.\n\nMa'lumotlarga faqat Laziza kira oladi. Ularni sotmayman va reklama xizmatlariga bermayman. Ular bot ishlayotgan serverda turadi, haftasiga bir marta baza nusxasi Lazizaga Telegram orqali yuboriladi.\n\n<b>Sizning huquqlaringiz</b>\n· ma'lumotlaringiz nusxasini olish: /mydata\n· hammasini o'chirish: /deletemydata (qonun saqlashni majbur qiladigan narsalar bundan mustasno, agar shunday talab bo'lsa)\n· ma'lumotlarni tuzatish, qayta ishlashni cheklash, e'tiroz bildirish yoki rozilikni qaytarib olish: bot orqali Lazizaga yozing\n· huquqlaringiz buzilyapti desangiz, o'z mamlakatingizdagi shaxsiy ma'lumotlarni himoya qilish organiga shikoyat qilish\n\nO'quvchi voyaga yetmagan bo'lsa, buni ota-ona ham qila oladi: bot orqali Lazizaga yozing.\n\nYangilangan: 2026-yil oktabr. O'zgarishlar shu yerda, /privacy da e'lon qilinadi.",
 "mydata_caption": "📄 Bot siz haqingizda saqlayotgan barcha ma'lumotlar nusxasi.",
 "mydata_empty": "Hozircha sizning ma'lumotlaringiz yo'q.",
 "del_ask": "Botdagi barcha ma'lumotlaringiz o'chirilsinmi: profil, darslar, to'lovlar, test natijalari, jadval? Buni qaytarib bo'lmaydi.",
 "btn_del_yes": "🗑 Ha, o'chirish",
 "btn_del_no": "Bekor qilish",
 "del_done": "Tayyor, hammasi o'chirildi. Qaytmoqchi bo'lsangiz, /start ni bosing 🍵",
 "del_cancel": "Yaxshi, hech narsa o'chirmadim.",
 "ask_source": "Tanishganimdan xursandman, {name}!\n\nMen haqimda qayerdan bildingiz?",
 "ask_level": "Oxirgi savol: xitoy tili darajangiz qanday?",
 "done": "Tayyor, {name}! Xush kelibsiz 🐉",
 "menu": "Nima qilamiz?",
 "hi": "你好 (nǐ hǎo — salom)",
 "welcome_back": "{hi}, {name}! 🐉\nMen 茶茶 (ChaCha), xitoy tili bo'yicha choy yordamchisiman. Yana ko'rganimdan xursandman 🍵\n\nMen nimalarga qodirman:\n📚 kunning so'zi va 🧧 chengyu\n🌏 Xitoy haqida faktlar\n🔤 pinyinli tarjima\n📐 grammatika va 📖 darajalar bo'yicha matnlar\n📊 natijalar va 🗓 dars eslatmalari, agar Laziza bilan shug'ullansangiz\n\nKerakli narsani topolmadingizmi? Shunchaki yozing, Lazizaga yetkazaman 💌\n\nMenyu pastda 👇",
 "b_sched": "🗓 Darslar",
 "sch_title": "🗓 <b>Mening darslarim</b>",
 "sch_days": "Jadval",
 "sch_next": "Eng yaqin dars",
 "sch_today": "bugun", "sch_tomorrow": "ertaga",
 "sch_remind": "🔔 Darsdan bir kun va bir soat oldin eslatib qo'yaman.",
 "sch_empty": "Jadval hozircha belgilanmagan. Laziza uni qo'shadi, shunda eslatishni boshlayman 🔔",
 "sch_guest": "Dars eslatmalari Lazizaning o'quvchilariga keladi 🔔 Agar u bilan shug'ullanayotgan bo'lsangiz, shu yerga yozing, men yetkazaman, Laziza sizni ro'yxatga qo'shadi.",
 "student_welcome": "🎓 Siz endi Lazizaning o'quvchilari ro'yxatidasiz! Bu yerda natijalaringiz va dars eslatmalari bo'ladi.",
 "sources": ["«Chayevnichaem o kitayskom» kanali", "Do'stdan", "Guruh yoki chatdan", "Laziza bilan shug'ullanaman", "Boshqa"],
 "levels": ["Endi boshlayapman", "HSK 1", "HSK 2", "HSK 3", "HSK 4", "HSK 5", "HSK 6", "HSK 7–9"],
 "b_word": "📚 Kunning so'zi", "b_chengyu": "🧧 Chengyu", "b_fact": "🌏 Xitoy fakti",
 "b_tr": "🔤 Tarjima", "b_progress": "📊 Natijam", "b_lang": "🌐 Til",
 "b_channel": "📢 Kanal", "b_help": "❓ Yordam",
 "word": "📚 Kunning so'zi", "chengyu": "🧧 Kunning chengyusi", "fact": "🌏 Xitoy haqida fakt",
 "tr_ask": "So'z yozing, o'zbekcha yoki xitoycha:",
 "tr_none": "«{q}» topilmadi 🔄\nXitoycha yoki inglizcha yozib ko'ring. So'rovingizni yozib qo'ydim, lug'at to'ldiriladi.",
 "tr_en_note": "Ma'nolar hozircha inglizcha: rus va o'zbek lug'atini hali to'ldiryapman.",
 "tr_split": "So'zlar bo'yicha:",
 "channel": "📢 Xitoy tili va madaniyati haqidagi kanalim:\nhttps://t.me/qing_laoshi",
 "help": ("汉助, xitoy tili yordamchisi\nLaziza Ropijonova yaratgan\n\n"
          "/menu menyu\n/word kunning so'zi\n/chengyu chengyu\n/fact fakt\n"
          "/translate tarjima\n/progress natijam\n/lang tilni almashtirish\n/about nimalarga qodirman\n/privacy maxfiylik\n/mydata ma'lumotlarim nusxasi\n/deletemydata ma'lumotlarimni o'chirish\n\n"
          "O'zingizdan biror narsa yozsangiz, uni Lazizaga yetkazaman, u o'zi javob beradi."),
 "no_progress": ("Hozircha bo'sh 🌱\n\nBu bo'lim Laziza bilan darslar boshlanganda to'ladi: "
                 "o'tilgan darslar, to'lov va test natijalari ko'rinadi."),
 "p_title": "📊 Sizning natijangiz", "p_lessons": "O'tilgan darslar", "p_paid": "To'langan",
 "p_left": "Qoldi", "p_renew": "Darslarni uzaytirish vaqti, Lazizaga yozing",
 "p_tests": "📈 Test natijalari", "p_first": "Birinchi", "p_last": "Oxirgi",
 "p_growth": "O'sish", "p_pp": "f.p.", "p_no_tests": "Hozircha testlar bo'lmagan.",
 "p_recent": "🗓 Oxirgi darslar", "p_sched": "Dars jadvali",
 "lang_pick": "Muloqot tilini tanlang", "lang_changed": "Tayyor, endi o'zbek tilida gaplashamiz 🐉",
 "day_today": "bugun", "day_tomorrow": "ertaga",
 "remind24": "🗓 Dars {day} soat <b>{time}</b> da.\nHammasi o'z kuchidami?",
 "remind1": "⏰ Bir soatdan keyin dars ({time}).", "remind1_link": "\n\nHavola: {link}",
 "btn_yes": "✅ Kelaman", "btn_no": "❌ Kela olmayman",
 "att_yes": "Ajoyib, kutaman 🐉",
 "att_ask": "Afsus 😔 Sababini bitta xabarda yozing, Lazizaga yetkazaman.",
 "att_ok": "Lazizaga yetkazdim, u ko'chirish haqida bog'lanadi 🤍",
 "att_late": "Lazizaga yetkazdim 🤍\nEslatma: shartlarga ko'ra, 3 soatdan kech bekor qilingan dars o'tilgan hisoblanadi.",
 "att_past": "Bu dars allaqachon o'tib ketdi.",
 "pay_nudge": "Salom! To'langan darslar tugab qoldi. Qulay payt Lazizaga yozing, davom ettiramiz 🤍",
 "q_sent": "Xabaringizni Lazizaga yetkazdim, u o'zi javob beradi 🤍",
},
"en": {
 "b_grammar": "📐 Grammar",
 "b_texts": "📖 Texts",
 "b_adult": "🔞 Swear words 16+",
 "ru_only": "For now in Russian only.",
 "gr_title": "📐 <b>HSK {lvl} grammar</b> · {n} of {total}",
 "gr_fallback": "There is no grammar for your level yet, showing the highest available: HSK {lvl}.",
 "gr_formula": "Pattern",
 "tx_adapted": "Adapted text",
 "tx_classic": "Classic",
 "tx_title": "📖 <b>{kind}</b> · {lvl} · {n} of {total}",
 "tx_lvl_any": "any level",
 "tx_translation": "Translation",
 "tx_empty": "No texts in this section yet.",
 "adult_head": "🔞 <b>Rude language 16+</b>",
 "adult_gate": "🔞 <b>16+ section</b>\n\nRude words and swearing: so that you understand what people say in dramas and on the street, not so that you use it.\n\nAre you 16 or older?",
 "adult_yes": "Yes, I'm 16 or older",
 "adult_no": "No",
 "adult_declined": "Okay, another time 🙂",
 "adult_closed": "This section is closed for you.",
 "adult_more": "➡️ More",
 "adult_lv1": "🟡 mildly rude",
 "adult_lv2": "🟠 rude",
 "adult_lv3": "🔴 very rude",
 "adult_rude": "Rudeness",
 "adult_foot": "⚠️ To understand, not to use: you can't talk like this in polite company.",
 "slang_label": "🔥 Internet slang",
 "bkrs_more": "",
 "bkrs_btn": "",
 "greet": "🍵 <b>Hello, hello!</b>\n\nMy name is <b>茶茶 (ChaCha)</b>, I'm a tiny tea spirit 🌿\nI live in a gaiwan cup and work as Laziza's Chinese learning assistant ✨\n\n<i>I'll pour you a little Chinese: no rush, no cramming</i> 🫖\n\nLet's get to know each other! What's your name?",
 "features": "Here's how I can help:\n\n📚 <b>Word of the day</b>\n🧧 <b>Chengyu</b>\n🌏 <b>Facts about China</b>, when you want something small and interesting\n🔤 <b>Translation</b> to Chinese and back, with pinyin\n📊 <b>Progress</b>, if you study with Laziza: lessons, payments, test results\n🗓 <b>Reminders</b> about lessons\n\nCan't find what you need? Just write to me, I'll pass it to Laziza and she'll reply herself 💌\n\nThe menu is below, start anywhere 👇\n<i>How I handle your data: /privacy</i>",
 "about_head": "🍵 <b>茶茶 (ChaCha)</b> · 汉助 Bot\nA tea-flavored Chinese learning assistant",
 "privacy": "🔒 <b>Privacy</b>\n\nI only keep what's needed for the bot to work:\n· your Telegram ID and @username\n· your name, language, level and how you found me\n· if you're a student: the number of lessons held and paid for, schedule, test results, lesson confirmations and cancellations with reasons\n· which bot buttons you use (just a counter, no text)\n· which words, chengyu and facts I have already shown you, so I don't repeat them\n· a mark that you confirmed you are 16+ (if you opened the 16+ section)\n· words from “Translate” that weren't found in the dictionary (the text of the query, not linked to you)\n\nYour messages to me are not stored in the bot's database, they are only forwarded to Laziza.\n\nOnly Laziza has access to this data. I don't sell it or share it with advertisers. It is stored on the server where the bot runs, and once a week a copy of the database is sent to Laziza on Telegram.\n\n<b>Your rights</b>\n· get a copy of your data: /mydata\n· delete everything: /deletemydata (except what the law requires to be kept, if any such requirement applies)\n· correct your data, restrict or object to its processing, or withdraw consent: write to Laziza through the bot\n· lodge a complaint with the data protection authority of your country if you believe your rights are not being upheld\n\nIf a student is a minor, a parent can do all of this by writing to Laziza through the bot.\n\nUpdated: October 2026. Changes are published here, in /privacy.",
 "mydata_caption": "📄 A copy of all the data the bot keeps about you.",
 "mydata_empty": "I don't have any of your data yet.",
 "del_ask": "Delete all your data from the bot: profile, lessons, payments, test results, schedule? This can't be undone.",
 "btn_del_yes": "🗑 Yes, delete",
 "btn_del_no": "Cancel",
 "del_done": "Done, everything is deleted. If you want to come back, press /start 🍵",
 "del_cancel": "Okay, nothing was deleted.",
 "ask_source": "Nice to meet you, {name}!\n\nHow did you find out about me?",
 "ask_level": "Last one: what's your Chinese level?",
 "done": "All set, {name}! Welcome 🐉",
 "menu": "What would you like?",
 "hi": "你好 (nǐ hǎo — hello)",
 "welcome_back": "{hi}, {name}! 🐉\nI'm 茶茶 (ChaCha), your tea-flavored Chinese helper. So glad you're back 🍵\n\nHere's what I can do:\n📚 word of the day and 🧧 chengyu\n🌏 facts about China\n🔤 translation with pinyin\n📐 grammar and 📖 texts by level\n📊 progress and 🗓 lesson reminders, if you study with Laziza\n\nCan't find what you need? Just write to me, I'll pass it to Laziza 💌\n\nPick something from the menu below 👇",
 "b_sched": "🗓 Lessons",
 "sch_title": "🗓 <b>My lessons</b>",
 "sch_days": "Schedule",
 "sch_next": "Next lesson",
 "sch_today": "today", "sch_tomorrow": "tomorrow",
 "sch_remind": "🔔 I'll remind you a day and an hour before each lesson.",
 "sch_empty": "No schedule set yet. Laziza will add it, and then I'll start sending reminders 🔔",
 "sch_guest": "Lesson reminders go to Laziza's students 🔔 If you already study with her, just write to me here, I'll pass it on and she'll add you to the list.",
 "student_welcome": "🎓 You're now on Laziza's student list! Your progress and lesson reminders will appear here.",
 "sources": ["Telegram channel", "From a friend", "From a group or chat", "I study with Laziza", "Other"],
 "levels": ["Just starting", "HSK 1", "HSK 2", "HSK 3", "HSK 4", "HSK 5", "HSK 6", "HSK 7–9"],
 "b_word": "📚 Word of the day", "b_chengyu": "🧧 Chengyu", "b_fact": "🌏 China fact",
 "b_tr": "🔤 Translate", "b_progress": "📊 My progress", "b_lang": "🌐 Language",
 "b_channel": "📢 Channel", "b_help": "❓ Help",
 "word": "📚 Word of the Day", "chengyu": "🧧 Chengyu of the Day", "fact": "🌏 Fact about China",
 "tr_ask": "Type a word, in English or Chinese:",
 "tr_none": "Couldn't find “{q}” 🔄\nTry a word in Chinese or English. I've noted your request, the dictionary keeps growing.",
 "tr_en_note": "",
 "tr_split": "Word by word:",
 "channel": "📢 My channel about Chinese language and culture:\nhttps://t.me/qing_laoshi",
 "help": ("汉助, Chinese learning assistant\nCreated by Laziza Ropijonova\n\n"
          "/menu menu\n/word word of the day\n/chengyu chengyu\n/fact China fact\n"
          "/translate translate\n/progress my progress\n/lang change language\n/about what I can do\n/privacy privacy\n/mydata a copy of my data\n/deletemydata delete my data\n\n"
          "If you write me something of your own, I'll pass it to Laziza and she'll reply herself."),
 "no_progress": ("Nothing here yet 🌱\n\nThis section fills up once you start lessons with Laziza: "
                 "lessons completed, payments and test results."),
 "p_title": "📊 Your progress", "p_lessons": "Lessons completed", "p_paid": "Paid for",
 "p_left": "Remaining", "p_renew": "Time to renew, message Laziza",
 "p_tests": "📈 Test results", "p_first": "First", "p_last": "Latest",
 "p_growth": "Change", "p_pp": "pp", "p_no_tests": "No tests yet.",
 "p_recent": "🗓 Recent lessons", "p_sched": "Schedule",
 "lang_pick": "Choose your language", "lang_changed": "Done, we'll talk in English now 🐉",
 "day_today": "today", "day_tomorrow": "tomorrow",
 "remind24": "🗓 Lesson {day} at <b>{time}</b>.\nStill good?",
 "remind1": "⏰ Lesson in one hour ({time}).", "remind1_link": "\n\nLink: {link}",
 "btn_yes": "✅ I'll be there", "btn_no": "❌ Can't make it",
 "att_yes": "Great, see you 🐉",
 "att_ask": "Sorry to hear 😔 Please write the reason in one message, I'll pass it to Laziza.",
 "att_ok": "Passed to Laziza, she'll contact you about rescheduling 🤍",
 "att_late": "Passed to Laziza 🤍\nReminder: under the terms, cancelling less than 3 hours before counts as a held lesson.",
 "att_past": "That lesson has already passed.",
 "pay_nudge": "Hi! Your paid lessons are almost used up. Whenever it's convenient, message Laziza about renewing 🤍",
 "q_sent": "Passed your message to Laziza, she'll reply herself 🤍",
},
"zh": {
 "b_grammar": "📐 语法",
 "b_texts": "📖 阅读",
 "b_adult": "🔞 脏话 16+",
 "ru_only": "目前只有俄语版。",
 "gr_title": "📐 <b>HSK {lvl} 语法</b> · 第{n}条，共{total}条",
 "gr_fallback": "你的水平暂时还没有语法内容，先显示现有最高的：HSK {lvl}。",
 "gr_formula": "句型",
 "tx_adapted": "改编文章",
 "tx_classic": "经典作品",
 "tx_title": "📖 <b>{kind}</b> · {lvl} · 第{n}篇，共{total}篇",
 "tx_lvl_any": "不限水平",
 "tx_translation": "翻译",
 "tx_empty": "这个栏目暂时没有文章。",
 "adult_head": "🔞 <b>粗话 16+</b>",
 "adult_gate": "🔞 <b>16+ 栏目</b>\n\n这里是粗话和脏话：为了看懂剧里和街上的人在说什么，而不是为了使用。\n\n你已满16岁了吗？",
 "adult_yes": "是的，我已满16岁",
 "adult_no": "没有",
 "adult_declined": "好的，下次吧 🙂",
 "adult_closed": "此栏目对你不开放。",
 "adult_more": "➡️ 下一个",
 "adult_lv1": "🟡 略粗鲁",
 "adult_lv2": "🟠 粗鲁",
 "adult_lv3": "🔴 非常粗鲁",
 "adult_rude": "粗鲁程度",
 "adult_foot": "⚠️ 只是为了看懂，不是为了使用：礼貌场合不能这样说。",
 "slang_label": "🔥 网络用语",
 "bkrs_more": "",
 "bkrs_btn": "",
 "greet": "🍵 <b>你好呀！</b>\n\n我是<b>茶茶 (Chá Chá)</b>，一只小小的茶精灵 🌿\n我住在盖碗里，给 Laziza 老师当汉语学习小助手 ✨\n\n<i>让我给你倒一点汉语：不着急，也不死记硬背</i> 🫖\n\n先认识一下吧！你叫什么名字？",
 "features": "我能帮你做这些：\n\n📚 <b>每日词汇</b>\n🧧 <b>成语</b>\n🌏 <b>中国小知识</b>，想看点轻松有趣的时候\n🔤 <b>翻译</b>：中文和母语互译，带拼音\n📊 <b>进度</b>：如果你在跟 Laziza 上课，可以看课时、付款和测试成绩\n🗓 上课<b>提醒</b>\n\n没找到想要的？直接给我留言，我会转给 Laziza，她会亲自回复 💌\n\n菜单在下面，随便从哪里开始 👇\n<i>我如何处理你的数据：/privacy</i>",
 "about_head": "🍵 <b>茶茶 (Chá Chá)</b> · 汉助 Bot\n茶香汉语小助手",
 "privacy": "🔒 <b>隐私</b>\n\n我只保存让机器人正常工作所需的内容：\n· 你的 Telegram ID 和用户名\n· 你的名字、语言、水平，以及你是怎么知道我的\n· 如果你是学员：已上和已付的课时数、课程时间、测试成绩、上课确认和请假（含原因）\n· 你用了机器人的哪些按钮（只是计数，不含文字）\n· 我已经给你看过哪些词汇、成语和小知识，避免重复\n· 你确认已满16岁的标记（如果打开过16+栏目）\n· “翻译”里词典没有找到的词（只记录查询文字，不关联到你）\n\n你发给我的消息不会保存在机器人的数据库里，只会转给 Laziza。\n\n只有 Laziza 能查看这些数据。我不会出售，也不会提供给广告服务。数据保存在机器人运行的服务器上，每周会把一份数据库副本通过 Telegram 发给 Laziza。\n\n<b>你的权利</b>\n· 获取你的数据副本：/mydata\n· 删除全部数据：/deletemydata（法律要求必须保留的内容除外，如果存在这类要求）\n· 更正数据、限制或反对处理、撤回同意：通过机器人联系 Laziza\n· 如果你认为自己的权利没有得到保障，可向你所在国家的个人数据保护机构投诉\n\n如果学员未成年，家长也可以通过机器人联系 Laziza 办理以上事项。\n\n更新时间：2026年10月。变更会发布在这里，即 /privacy。",
 "mydata_caption": "📄 机器人保存的关于你的所有数据副本。",
 "mydata_empty": "我这里暂时没有你的数据。",
 "del_ask": "要删除你在机器人里的所有数据吗：资料、课时、付款、测试成绩、课程时间？此操作无法撤销。",
 "btn_del_yes": "🗑 是，删除",
 "btn_del_no": "取消",
 "del_done": "好了，全部已删除。想回来的话，点 /start 🍵",
 "del_cancel": "好的，什么都没有删除。",
 "ask_source": "很高兴认识你，{name}！\n\n你是怎么知道我的？",
 "ask_level": "最后一个问题：你的汉语水平是？",
 "done": "都准备好了，{name}！欢迎 🐉",
 "menu": "想做什么？",
 "hi": "你好 (nǐ hǎo)",
 "welcome_back": "{hi}，{name}！🐉\n我是茶茶，你的茶香汉语小助手。很高兴你又来了 🍵\n\n我能做这些：\n📚 每日词汇和 🧧 成语\n🌏 中国小知识\n🔤 带拼音的翻译\n📐 语法和 📖 分级阅读\n📊 进度和 🗓 上课提醒（如果你在跟 Laziza 上课）\n\n没找到想要的？直接给我留言，我会转给 Laziza 💌\n\n从下面的菜单开始吧 👇",
 "b_sched": "🗓 课程",
 "sch_title": "🗓 <b>我的课程</b>",
 "sch_days": "课程时间",
 "sch_next": "下一节课",
 "sch_today": "今天", "sch_tomorrow": "明天",
 "sch_remind": "🔔 我会在上课前一天和前一小时提醒你。",
 "sch_empty": "还没有设置课程时间。Laziza 添加后，我就会开始提醒你 🔔",
 "sch_guest": "上课提醒会发给 Laziza 的学员 🔔 如果你已经在跟她上课，直接在这里给我留言，我会转告，她会把你加入学员名单。",
 "student_welcome": "🎓 你已加入 Laziza 的学员名单！这里会显示你的进度和上课提醒。",
 "sources": ["电报频道", "朋友介绍", "群聊", "我在跟 Laziza 学习", "其他"],
 "levels": ["刚开始", "HSK 1", "HSK 2", "HSK 3", "HSK 4", "HSK 5", "HSK 6", "HSK 7–9"],
 "b_word": "📚 今日词汇", "b_chengyu": "🧧 成语", "b_fact": "🌏 中国小知识",
 "b_tr": "🔤 翻译", "b_progress": "📊 我的进度", "b_lang": "🌐 语言",
 "b_channel": "📢 频道", "b_help": "❓ 帮助",
 "word": "📚 今日词汇", "chengyu": "🧧 今日成语", "fact": "🌏 关于中国",
 "tr_ask": "请输入要翻译的词：",
 "tr_none": "没找到「{q}」🔄\n试试输入中文或英文。我已记下你的查询，词典会不断补充。",
 "tr_en_note": "释义暂时是英文：俄语和乌兹别克语词典还在补充中。",
 "tr_split": "逐词解释：",
 "channel": "📢 我的汉语和文化频道：\nhttps://t.me/qing_laoshi",
 "help": ("汉助，汉语学习助手\n由 Laziza Ropijonova 创建\n\n"
          "/menu 菜单\n/word 今日词汇\n/chengyu 成语\n/fact 小知识\n"
          "/translate 翻译\n/progress 我的进度\n/lang 切换语言\n/about 我能做什么\n/privacy 隐私\n/mydata 我的数据副本\n/deletemydata 删除我的数据\n\n"
          "你写给我的其他内容，我会转给 Laziza，她会亲自回复。"),
 "no_progress": "这里还是空的 🌱\n\n开始上课后，这里会显示课时、付款和测试成绩。",
 "p_title": "📊 你的进度", "p_lessons": "已上课时", "p_paid": "已付课时",
 "p_left": "剩余", "p_renew": "该续费了，请联系 Laziza",
 "p_tests": "📈 测试成绩", "p_first": "第一次", "p_last": "最近",
 "p_growth": "变化", "p_pp": "个百分点", "p_no_tests": "还没有测试记录。",
 "p_recent": "🗓 最近的课", "p_sched": "课程时间",
 "lang_pick": "请选择语言", "lang_changed": "好的，现在用中文交流 🐉",
 "day_today": "今天", "day_tomorrow": "明天",
 "remind24": "🗓 {day} <b>{time}</b> 有课。\n时间没问题吗？",
 "remind1": "⏰ 一小时后上课（{time}）。", "remind1_link": "\n\n链接：{link}",
 "btn_yes": "✅ 我会来", "btn_no": "❌ 来不了",
 "att_yes": "好的，等你 🐉",
 "att_ask": "太遗憾了 😔 请用一条消息写下原因，我会转告 Laziza。",
 "att_ok": "已转告 Laziza，她会联系你改期 🤍",
 "att_late": "已转告 Laziza 🤍\n提醒：按约定，提前不足3小时取消的课按已上课计算。",
 "att_past": "这节课已经结束了。",
 "pay_nudge": "你好！已付费的课快上完了。方便的时候请联系 Laziza 续费 🤍",
 "q_sent": "已把你的消息转给 Laziza，她会亲自回复 🤍",
},
}


def t(lang, key, **kw):
    table = T.get(lang, T["ru"])
    # пустая строка в языке означает «здесь намеренно ничего нет», а не «текста нет, возьми русский»
    s = table[key] if key in table else T["ru"].get(key, key)
    return s.format(**kw) if kw and s else s


# Профиль бота в Telegram. Бот выставляет его сам при запуске (см. apply_profile в bot.py).
# Описание: до 512 знаков, «о боте»: до 120, имя: до 64. Язык = язык приложения Telegram у человека.
PROFILE = {
 "ru": {"name": "汉助 — Chinese Learning Assistant",
        "description": "🍵 Привет! Я 茶茶 (ЧаЧа), чайный помощник по китайскому.\n\nСлово дня, чэнъюй, факты о Китае, перевод с пиньинем, напоминания об уроках и твой прогресс, если занимаешься с преподавателем. Говорю по-русски, по-узбекски, по-английски и по-китайски.\n\nНажми «Запустить», и давай знакомиться 🌿",
        "short": "Чайный помощник по китайскому: слова, чэнъюй, перевод и напоминания об уроках 🍵"},
 "uz": {"name": "汉助 — Chinese Learning Assistant",
        "description": "🍵 Salom! Men 茶茶 (ChaCha), xitoy tili bo'yicha choy yordamchisiman.\n\nKunning so'zi, chengyu, Xitoy haqida faktlar, pinyinli tarjima, darslar haqida eslatmalar va o'qituvchi bilan shug'ullansangiz, natijangiz. Rus, o'zbek, ingliz va xitoy tillarida gaplashaman.\n\nBoshlash tugmasini bosing, tanishamiz 🌿",
        "short": "Xitoy tili bo'yicha choy yordamchisi: so'zlar, chengyu, tarjima va darslar haqida eslatmalar 🍵"},
 "en": {"name": "汉助 — Chinese Learning Assistant",
        "description": "🍵 Hi! I'm 茶茶 (ChaCha), a tea-flavored Chinese learning assistant.\n\nWord of the day, chengyu, facts about China, translation with pinyin, lesson reminders and your progress if you study with a teacher. I speak Russian, Uzbek, English and Chinese.\n\nPress Start and let's get acquainted 🌿",
        "short": "A tea-flavored Chinese helper: words, chengyu, translation and lesson reminders 🍵"},
 "zh": {"name": "汉助 — Chinese Learning Assistant",
        "description": "🍵 你好！我是茶茶 (Chá Chá)，茶香汉语小助手。\n\n每日词汇、成语、中国小知识、带拼音的翻译、上课提醒，如果你在跟老师上课，还能看到学习进度。我会说俄语、乌兹别克语、英语和中文。\n\n点“开始”，我们认识一下吧 🌿",
        "short": "茶香汉语小助手：词汇、成语、翻译和上课提醒 🍵"},
}


# ─── Новые функции: практика, пробный урок, друзья, домашки ──────────────────
from texts_practice import P as _P, WELCOME_LINE as _WL

for _lang in T:
    T[_lang].update(_P.get(_lang, {}))
    _wb = T[_lang].get("welcome_back", "")
    if _wb and _WL.get(_lang) and _WL[_lang] not in _wb:
        T[_lang]["welcome_back"] = _wb.replace("\n📊", "\n" + _WL[_lang] + "📊", 1)

# ─── Обновления политики и справки под новые функции ─────────────────────────
_PRIV_ADD = {
    "ru": ("\n\nТвои сообщения мне бот", "· прогресс в карточках и тренировке слов (какие слова учишь, монеты, звания)\n· если пришёл(ла) по ссылке друга: кто пригласил (вы оба получаете уведомление с именем друг друга); если приглашаешь сам(а): сколько друзей пришло\n· домашние задания, просьбы о переносе урока и оценка занятий с текстом отзыва (если оставишь)"),
    "uz": ("\n\nMenga yozgan xabarlaringizni", "· kartochkalar va So'z mashqidagi progress (qaysi so'zlarni o'rganyapsiz, tangalar, unvonlar)\n· do'st havolasi orqali kelgan bo'lsangiz: kim taklif qilgani (ikkalangizga ham bir-biringizning ismingiz bilan xabar boradi); o'zingiz taklif qilsangiz: nechta do'st kelgani\n· uy vazifalari, darsni ko'chirish so'rovlari va darslarni baholash (fikr matni bilan, agar qoldirsangiz)"),
    "en": ("\n\nYour messages to me are not stored", "· your progress in flashcards and Word practice (which words you study, coins, ranks)\n· if you came through a friend's link: who invited you (you both get a notification with each other's name); if you invite someone: how many friends came\n· homework, lesson reschedule requests and your lesson rating with the review text (if you leave one)"),
    "zh": ("\n\n你发给我的消息不会保存", "· 你在单词卡和单词练习里的进度（学了哪些词、金币、称号）\n· 如果你是通过朋友的链接来的：是谁邀请的（你们双方都会收到带对方名字的通知）；如果你邀请别人：来了几位朋友\n· 作业、调课请求，以及你对课程的评分和评价文字（如果你留下的话）"),
}
for _l, (_anchor, _add) in _PRIV_ADD.items():
    _p = T[_l].get("privacy", "")
    if _p and _anchor in _p and _add not in _p:
        T[_l]["privacy"] = _p.replace(_anchor, "\n" + _add + _anchor, 1)

_HELP_ADD = {
    "ru": "/practice викторина, карточки, игра\n/friend пригласить друга\n/trial пробный урок\n",
    "uz": "/practice viktorina, kartochkalar, o'yin\n/friend do'stni taklif qilish\n/trial sinov darsi\n",
    "en": "/practice quiz, flashcards, game\n/friend invite a friend\n/trial trial lesson\n",
    "zh": "/practice 测验、单词卡、游戏\n/friend 邀请朋友\n/trial 试听课\n",
}
for _l, _add in _HELP_ADD.items():
    _h = T[_l].get("help", "")
    if _h and _add not in _h:
        T[_l]["help"] = _h.replace("/lang ", _add + "/lang ", 1)

# ─── Версия 8: марафон, сдача домашки, полный китайский ──────────────────────
from texts_v8 import P as _P8

for _lang in T:
    T[_lang].update(_P8.get(_lang, {}))

_PRIV_HW = {
    "ru": ("· домашние задания, просьбы", "· фото и файлы домашки бот не хранит: он пересылает их Лазизе, у бота остаётся только отметка «сдано»\n"),
    "uz": ("· uy vazifalari, darsni ko'chirish", "· uy vazifasi suratlari va fayllarini bot saqlamaydi: ularni Lazizaga yuboradi, botda faqat «topshirildi» belgisi qoladi\n"),
    "en": ("· homework, lesson reschedule", "· the bot does not store homework photos or files: it forwards them to Laziza, and only a “submitted” mark stays with the bot\n"),
    "zh": ("· 作业、调课请求", "· 机器人不保存作业照片和文件：只转发给 Laziza，机器人这边只留下“已提交”的记录\n"),
}
for _l, (_anchor, _add) in _PRIV_HW.items():
    _p = T[_l].get("privacy", "")
    if _p and _anchor in _p and _add not in _p:
        T[_l]["privacy"] = _p.replace(_anchor, _add + _anchor, 1)

# ─── Версия 9: правила игры, рейтинг недели, награда за друга ────────────────
from texts_v9 import P as _P9

for _lang in T:
    T[_lang].update(_P9.get(_lang, {}))

_PRIV_BOARD = {
    "ru": ("· домашние задания, просьбы", "· если вступишь в рейтинг недели: твоё первое имя и очки видны другим участникам (выйти можно в любой момент)\n"),
    "uz": ("· uy vazifalari, darsni ko'chirish", "· hafta reytingiga qo'shilsangiz: ismingizning birinchi so'zi va ochkolaringiz boshqa ishtirokchilarga ko'rinadi (istalgan vaqtda chiqish mumkin)\n"),
    "en": ("· homework, lesson reschedule", "· if you join the weekly ranking: your first name and points are visible to other participants (you can leave at any time)\n"),
    "zh": ("· 作业、调课请求", "· 如果你加入每周排行榜：你名字的第一个词和积分会被其他参与者看到（可随时退出）\n"),
}
for _l, (_anchor, _add) in _PRIV_BOARD.items():
    _p = T[_l].get("privacy", "")
    if _p and _anchor in _p and _add not in _p:
        T[_l]["privacy"] = _p.replace(_anchor, _add + _anchor, 1)

# ─── Версия 10: скидочные месяцы, продление без Stars, ники, родители ────────
from texts_v10 import P as _P10, RULES_PATCH as _RP10, PRIVACY_PATCH as _PP10

for _lang in T:
    T[_lang].update(_P10.get(_lang, {}))

for _l, _pairs in _RP10.items():
    _r = T[_l].get("rules", "")
    for _old, _new in _pairs:
        if _old in _r:
            _r = _r.replace(_old, _new, 1)
    T[_l]["rules"] = _r

for _l, (_old, _new) in _PP10.items():
    _p = T[_l].get("privacy", "")
    if _old in _p:
        T[_l]["privacy"] = _p.replace(_old, _new, 1)

# ─── Версия 11: игра «Путешествие по Китаю с 茶茶», Stars, поддержка проекта ─────────
from texts_v11 import P as _P11

for _lang in T:
    T[_lang].update(_P11.get(_lang, {}))
