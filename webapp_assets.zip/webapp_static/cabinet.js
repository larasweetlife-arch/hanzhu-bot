/* 汉助 · вкладка «Кабинет»: ученик видит расписание, счётчик оплаченных уроков, отмены и переносы (только запросы);
   преподаватель (владелица) видит неделю, учеников и ведёт уроки. Все правила и проверки на сервере (cabinet.py).
   Связь с app.js через window.QY. */
(() => {
  "use strict";
  const Y = () => window.QY;
  const h = (...a) => Y().h(...a);
  const L = () => (Y().S && Y().S.lang) || "ru";
  const LOC = { ru: "ru-RU", uz: "uz-UZ", en: "en-GB", zh: "zh-CN" };
  const REASONS = ["sick", "family", "work", "tech", "force", "other"];
  const NEED_TEXT = ["force", "other"];

  const CT = {
    ru: {
      title_my: "Мои уроки", paid: "Оплачено", done: "Проведено", left: "Осталось", one_left: "Остался 1 оплаченный урок. Когда будет удобно, напиши Лазизе насчёт продления.",
      none_left: "Оплаченные уроки закончились. Напиши Лазизе насчёт продления.", debt: "Проведено на {n} ур. больше, чем оплачено.",
      next: "Ближайшие занятия", no_lessons: "Расписание пока не задано. Лазиза добавит его, и оно появится здесь.", btn_move: "Перенести", btn_cancel: "Отменить",
      cancelled: "Отменено", moved_student: "Перенесено по твоей просьбе", moved_teacher: "Перенесено по просьбе преподавателя", pend_move: "Запрос на перенос: {w}. Жду ответа Лазизы.",
      topics: "Пройденные темы", no_topics: "Пока нет отметок об уроках.", hist: "Отмены и переносы", no_topic: "без темы",
      r_sick: "🤒 Болезнь", r_family: "👨‍👩‍👧 Семья", r_work: "💼 Работа или учёба", r_tech: "💻 Техника или связь", r_force: "🆘 Форс-мажор", r_other: "✏️ Другое",
      cancel_title: "Отмена занятия", cancel_pick: "Выбери причину", cancel_ph: "Расскажи коротко, что случилось", late_note: "До занятия меньше {h} ч: по условиям урок спишется. Если случилось что-то непредвиденное, выбери «Форс-мажор»: Лазиза решит.",
      cancel_go: "Отменить занятие", cancel_ok: "Занятие отменено. Урок не списывается.", cancel_late: "Занятие отменено позже срока: урок засчитан. Лазиза учтёт, если это форс-мажор.",
      cancel_force: "Лазиза увидит твоё сообщение и решит, не списывать ли урок. Береги себя 🤍", need_reason: "Выбери причину", need_text: "Напиши, что случилось",
      move_title: "Перенос занятия", move_pick: "Выбери новый день и время", move_go: "Отправить запрос", move_sent: "Запрос отправлен. Лазиза ответит в чате с ботом.",
      err_past: "Это время уже прошло", err_dup: "Уже отправлено или отменено", err_bad: "Не получилось, проверь данные", err_far: "Слишком далеко вперёд", err_nolesson: "Такого занятия нет", err_same: "Это то же самое время",
      close: "Закрыть", lesson_of: "Занятие", by_student: "по просьбе ученика", by_teacher: "по просьбе преподавателя", log_cancel: "Отмена", log_move: "Перенос", st_pending: "ждёт ответа", st_ok: "принято", st_no: "отклонено", st_replaced: "заменено другим временем",
      force_ok: "форс-мажор: не списано", force_pending: "форс-мажор: решает Лазиза", charged: "списано",
      tab_week: "Неделя", tab_students: "Ученики", pending: "Ждут решения", req_move: "просит перенос", req_force: "форс-мажор", accept: "Принять", reject: "Отказать", other_time: "Другое время",
      held: "Провёл", mark: "Урок проведён", topic_ph: "Тема урока (можно пропустить)", save: "Отметить", cancel_btn: "Отменить", move_btn: "Перенести", force_btn: "Форс-мажор",
      add_pay: "Внести оплату", pay_ph: "Сколько уроков оплачено", pay_go: "Записать", pay_ok: "Оплата записана", no_students: "Учеников пока нет. Добавь их в боте: «Мои ученики».",
      back: "← Назад", who_q: "Чья инициатива?", who_student: "По просьбе ученика", who_teacher: "По моей инициативе", clash_q: "В это время уже урок: {n}. Перенести всё равно?", clash_go: "Всё равно перенести",
      moved_ok: "Перенос выполнен, ученик получил уведомление", cancelled_ok: "Урок отменён, ученик получил уведомление", held_ok: "Отмечено", decided: "Готово", next_l: "Ближайший", payments: "Оплаты", lessons_h: "Проведённые уроки",
      late_req: "Запрос пришёл меньше чем за {h} ч до урока: решаешь ты.",
      past_unmarked: "не отмечено", no_week: "На этой неделе уроков нет", lates: "поздняя отмена", held_l: "проведён", today: "Сегодня", sched: "Расписание",
    },
    uz: {
      title_my: "Mening darslarim", paid: "To'langan", done: "O'tilgan", left: "Qolgan", one_left: "1 ta to'langan dars qoldi. Qulay payt Lazizaga yozing, davom ettiramiz.",
      none_left: "To'langan darslar tugadi. Davom ettirish uchun Lazizaga yozing.", debt: "To'langandan {n} ta ko'p dars o'tilgan.",
      next: "Eng yaqin darslar", no_lessons: "Jadval hozircha belgilanmagan. Laziza uni qo'shadi, shunda shu yerda ko'rinadi.", btn_move: "Ko'chirish", btn_cancel: "Bekor qilish",
      cancelled: "Bekor qilingan", moved_student: "Sizning so'rovingiz bilan ko'chirilgan", moved_teacher: "O'qituvchi so'rovi bilan ko'chirilgan", pend_move: "Ko'chirish so'rovi: {w}. Lazizaning javobini kutaman.",
      topics: "O'tilgan mavzular", no_topics: "Hozircha dars belgilari yo'q.", hist: "Bekor qilish va ko'chirishlar", no_topic: "mavzusiz",
      r_sick: "🤒 Kasallik", r_family: "👨‍👩‍👧 Oila", r_work: "💼 Ish yoki o'qish", r_tech: "💻 Texnika yoki aloqa", r_force: "🆘 Fors-major", r_other: "✏️ Boshqa",
      cancel_title: "Darsni bekor qilish", cancel_pick: "Sababni tanlang", cancel_ph: "Nima bo'lganini qisqacha yozing", late_note: "Darsgacha {h} soatdan kam qoldi: shartlarga ko'ra dars hisobdan yechiladi. Kutilmagan holat bo'lsa, «Fors-major»ni tanlang: Laziza hal qiladi.",
      cancel_go: "Darsni bekor qilish", cancel_ok: "Dars bekor qilindi. Hisobdan yechilmaydi.", cancel_late: "Dars kech bekor qilindi: hisobga olindi. Fors-major bo'lsa, Laziza inobatga oladi.",
      cancel_force: "Laziza xabaringizni ko'radi va darsni hisobdan yechmaslikni hal qiladi. O'zingizni asrang 🤍", need_reason: "Sababni tanlang", need_text: "Nima bo'lganini yozing",
      move_title: "Darsni ko'chirish", move_pick: "Yangi kun va vaqtni tanlang", move_go: "So'rov yuborish", move_sent: "So'rov yuborildi. Laziza bot chatida javob beradi.",
      err_past: "Bu vaqt o'tib ketgan", err_dup: "Allaqachon yuborilgan yoki bekor qilingan", err_bad: "Bo'lmadi, ma'lumotlarni tekshiring", err_far: "Juda uzoq", err_nolesson: "Bunday dars yo'q", err_same: "Bu xuddi shu vaqt",
      close: "Yopish", lesson_of: "Dars", by_student: "o'quvchi so'rovi bilan", by_teacher: "o'qituvchi so'rovi bilan", log_cancel: "Bekor qilish", log_move: "Ko'chirish", st_pending: "javob kutilmoqda", st_ok: "qabul qilindi", st_no: "rad etildi", st_replaced: "boshqa vaqt bilan almashtirildi",
      force_ok: "fors-major: yechilmadi", force_pending: "fors-major: Laziza hal qiladi", charged: "yechildi",
    },
    en: {
      title_my: "My lessons", paid: "Paid", done: "Held", left: "Left", one_left: "1 paid lesson left. When convenient, write to Laziza about renewing.",
      none_left: "Paid lessons are over. Write to Laziza about renewing.", debt: "{n} more lessons held than paid.",
      next: "Upcoming lessons", no_lessons: "No schedule yet. Laziza will add it and it will appear here.", btn_move: "Reschedule", btn_cancel: "Cancel",
      cancelled: "Cancelled", moved_student: "Rescheduled at your request", moved_teacher: "Rescheduled at the teacher's request", pend_move: "Reschedule request: {w}. Waiting for Laziza's answer.",
      topics: "Topics covered", no_topics: "No lesson marks yet.", hist: "Cancellations and reschedules", no_topic: "no topic",
      r_sick: "🤒 Illness", r_family: "👨‍👩‍👧 Family", r_work: "💼 Work or study", r_tech: "💻 Tech or connection", r_force: "🆘 Emergency", r_other: "✏️ Other",
      cancel_title: "Cancel the lesson", cancel_pick: "Choose a reason", cancel_ph: "Briefly say what happened", late_note: "Less than {h} h before the lesson: under the terms it will be counted. If something unexpected happened, choose “Emergency” and Laziza will decide.",
      cancel_go: "Cancel the lesson", cancel_ok: "Lesson cancelled. It is not counted.", cancel_late: "Cancelled late: the lesson counts. Laziza will take it into account if it was an emergency.",
      cancel_force: "Laziza will see your message and decide not to count the lesson. Take care 🤍", need_reason: "Choose a reason", need_text: "Write what happened",
      move_title: "Reschedule the lesson", move_pick: "Choose a new day and time", move_go: "Send request", move_sent: "Request sent. Laziza will answer in the bot chat.",
      err_past: "That time has passed", err_dup: "Already sent or cancelled", err_bad: "Did not work, check the details", err_far: "Too far ahead", err_nolesson: "No such lesson", err_same: "That is the same time",
      close: "Close", lesson_of: "Lesson", by_student: "at the student's request", by_teacher: "at the teacher's request", log_cancel: "Cancellation", log_move: "Reschedule", st_pending: "waiting", st_ok: "accepted", st_no: "declined", st_replaced: "replaced by another time",
      force_ok: "emergency: not counted", force_pending: "emergency: Laziza decides", charged: "counted",
      tab_week: "Week", tab_students: "Students", pending: "Waiting for a decision", req_move: "asks to reschedule", req_force: "emergency", accept: "Accept", reject: "Decline", other_time: "Other time",
      held: "Held", mark: "Lesson held", topic_ph: "Lesson topic (optional)", save: "Mark", cancel_btn: "Cancel", move_btn: "Reschedule", force_btn: "Emergency",
      add_pay: "Add a payment", pay_ph: "How many lessons paid", pay_go: "Save", pay_ok: "Payment saved", no_students: "No students yet. Add them in the bot: “My students”.",
      back: "← Back", who_q: "Whose initiative?", who_student: "At the student's request", who_teacher: "At my initiative", clash_q: "There is already a lesson at that time: {n}. Reschedule anyway?", clash_go: "Reschedule anyway",
      moved_ok: "Rescheduled, the student was notified", cancelled_ok: "Lesson cancelled, the student was notified", held_ok: "Marked", decided: "Done", next_l: "Next", payments: "Payments", lessons_h: "Lessons held",
      late_req: "The request came less than {h} h before the lesson: it is your call.",
      past_unmarked: "not marked", no_week: "No lessons this week", lates: "late cancellation", held_l: "held", today: "Today", sched: "Schedule",
    },
    zh: {
      title_my: "我的课程", paid: "已付", done: "已上", left: "剩余", one_left: "还剩 1 节已付费的课。方便时请联系 Laziza 续费。",
      none_left: "已付费的课已用完。请联系 Laziza 续费。", debt: "已上课时比已付多 {n} 节。",
      next: "即将上的课", no_lessons: "还没有排课。Laziza 添加后会显示在这里。", btn_move: "改期", btn_cancel: "取消",
      cancelled: "已取消", moved_student: "按你的请求已改期", moved_teacher: "按老师的请求已改期", pend_move: "改期请求：{w}。等待 Laziza 回复。",
      topics: "已学内容", no_topics: "还没有上课记录。", hist: "取消与改期", no_topic: "无主题",
      r_sick: "🤒 生病", r_family: "👨‍👩‍👧 家里有事", r_work: "💼 工作或学习", r_tech: "💻 设备或网络", r_force: "🆘 突发情况", r_other: "✏️ 其他",
      cancel_title: "取消课程", cancel_pick: "请选择原因", cancel_ph: "简单说明发生了什么", late_note: "距上课不足 {h} 小时：按约定将计为已上课。如果发生了无法预料的情况，请选“突发情况”，由 Laziza 决定。",
      cancel_go: "取消课程", cancel_ok: "课程已取消，不扣课时。", cancel_late: "取消过晚：这节课将计入。如果是突发情况，Laziza 会酌情考虑。",
      cancel_force: "Laziza 会看到你的消息，并决定是否不扣这节课。请照顾好自己 🤍", need_reason: "请选择原因", need_text: "请写下发生了什么",
      move_title: "课程改期", move_pick: "请选择新的日期和时间", move_go: "发送请求", move_sent: "请求已发送。Laziza 会在机器人聊天中回复。",
      err_past: "这个时间已经过去了", err_dup: "已发送或已取消", err_bad: "没成功，请检查信息", err_far: "太遥远了", err_nolesson: "没有这节课", err_same: "这是同一个时间",
      close: "关闭", lesson_of: "课程", by_student: "按学生请求", by_teacher: "按老师请求", log_cancel: "取消", log_move: "改期", st_pending: "等待回复", st_ok: "已同意", st_no: "已拒绝", st_replaced: "已换成其他时间",
      force_ok: "突发情况：未扣课时", force_pending: "突发情况：Laziza 决定中", charged: "已扣课时",
    },
  };

  const C = { data: null, view: "main", off: 0, card: null, tab: "week", busy: false };

  function ct(k, v) {
    const d = CT[L()] || {};
    let s = d[k] !== undefined ? d[k] : CT.ru[k];
    if (s === undefined) return k;
    return v ? s.replace(/\{(\w+)\}/g, (_, x) => (v[x] !== undefined ? v[x] : "")) : s;
  }
  // тексты, которых нет в узбекском и китайском, берутся из английского (кабинет преподавателя), затем из русского
  const _ct = ct;
  function ctx(k, v) {
    const lang = L();
    if ((lang === "uz" || lang === "zh") && CT[lang][k] === undefined && CT.en[k] !== undefined) {
      return v ? CT.en[k].replace(/\{(\w+)\}/g, (_, x) => (v[x] !== undefined ? v[x] : "")) : CT.en[k];
    }
    return _ct(k, v);
  }

  const fmtDay = (d) => { try { return new Date(d + "T00:00:00").toLocaleDateString(LOC[L()], { weekday: "short", day: "numeric", month: "short" }); } catch (e) { return d; } };
  const fmtWhen = (iso) => fmtDay(iso.slice(0, 10)) + ", " + iso.slice(11, 16);
  const todayStr = () => {          // сегодняшняя дата по Ташкенту (UTC+5), чтобы min у календаря не зависел от часового пояса телефона
    const d = new Date(Date.now() + 5 * 3600 * 1000);
    return d.toISOString().slice(0, 10);
  };
  const errText = (r) => ctx("err_" + (r && r.err), null) !== "err_" + (r && r.err) ? ctx("err_" + r.err) : ctx("err_bad");

  async function load() {
    if (C.busy) return;
    C.busy = true;
    try {
      C.data = await Y().api("/api/cab/me", { offset: C.off });
      if (C.view === "card" && C.card) C.card = await Y().api("/api/cab/student", { uid: C.card.uid });
    } catch (e) {
      if (e.auth || e.consent) { C.busy = false; return Y().safe(async () => { throw e; }); }
      Y().toast(Y().tr("err"));
    }
    C.busy = false;
    Y().render();
  }
  function enter() { C.view = "main"; C.card = null; load(); }

  // ── общие кусочки ──
  function balanceCard(b, title) {
    const low = b.left <= 1;
    const warn = b.left < 0 ? ct("debt", { n: -b.left }) : b.left === 0 ? ct("none_left") : b.left === 1 ? ct("one_left") : null;
    const dots = b.pkg > 0 ? h("div", { class: "cab-dots", "aria-label": ct("paid") }, Array.from({ length: b.pkg }, (_, i) => h("span", { class: "cab-dot" + (i < b.pkg_done ? " on" : "") }, i < b.pkg_done ? "✓" : ""))) : null;
    return h("div", { class: "card" }, h("h3", {}, title),
      h("div", { class: "cab-stats" },
        h("div", { class: "cab-stat" }, h("b", {}, b.paid), h("span", {}, ct("paid"))),
        h("div", { class: "cab-stat" }, h("b", {}, b.done), h("span", {}, ct("done"))),
        h("div", { class: "cab-stat" + (low ? " low" : "") }, h("b", {}, b.left), h("span", {}, ct("left")))),
      dots, warn ? h("div", { class: "cab-warn" }, warn) : null);
  }
  function reasonLabel(code, text) {
    return (code ? ct("r_" + code) : "") + (text ? (code ? ": " : "") + text : "");
  }
  function histItem(r) {
    const who = r.who === "student" ? ctx("by_student") : ctx("by_teacher");
    if (r.kind === "cancel") {
      const st = r.status === "force_ok" ? ctx("force_ok") : r.status === "force_pending" ? ctx("force_pending") : r.status === "force_no" ? ctx("charged") : r.charged ? ctx("charged") : "";
      return h("div", { class: "cab-hist" }, h("b", {}, ctx("log_cancel") + " " + fmtWhen(r.lesson)), " · " + who, h("div", { class: "cab-sub" }, reasonLabel(r.code, r.text) + (st ? " · " + st : "")));
    }
    const st = r.status === "pending" ? ctx("st_pending") : r.status === "ok" ? ctx("st_ok") : r.status === "no" ? ctx("st_no") : ctx("st_replaced");
    return h("div", { class: "cab-hist" }, h("b", {}, ctx("log_move") + " " + fmtWhen(r.lesson) + (r.new ? " → " + fmtWhen(r.new) : "")), " · " + who, h("div", { class: "cab-sub" }, st));
  }
  function badges(x) {
    const out = [];
    if (x.status === "cancelled" && x.cancel) {
      const c = x.cancel;
      out.push(h("span", { class: "cab-badge bad" }, ct("cancelled") + (c.who === "teacher" ? " · " + ctx("by_teacher") : "")));
      if (c.state === "force_ok") out.push(h("span", { class: "cab-badge ok" }, ctx("force_ok")));
      else if (c.state === "force_pending") out.push(h("span", { class: "cab-badge gold" }, ctx("force_pending")));
      else if (c.charged) out.push(h("span", { class: "cab-badge gold" }, ctx("charged")));
    }
    if (x.moved_from) out.push(h("span", { class: "cab-badge" }, "🔄 " + (x.moved_by === "student" ? ct("moved_student") : ctx("moved_teacher")) + " (" + fmtWhen(x.moved_from) + ")"));
    if (x.status === "held") out.push(h("span", { class: "cab-badge ok" }, "✓ " + ctx("held_l")));
    if (x.status === "past") out.push(h("span", { class: "cab-badge" }, ctx("past_unmarked")));
    return out;
  }

  // ── окна: отмена, перенос, отметка ──
  function closeBtn() { return h("button", { class: "btn line sm", style: "margin-top:12px", onclick: (e) => { const w = e.target.closest(".sheetbg"); if (w) w.remove(); } }, ct("close")); }

  function cancelSheet(x, owner, uid) {
    let code = null;
    const txt = h("textarea", { placeholder: ct("cancel_ph"), maxlength: "300", class: "hidden" });
    const chips = REASONS.map((c) => h("button", { class: "cab-chip", onclick: () => {
      code = c;
      chips.forEach((b, i) => b.classList.toggle("on", REASONS[i] === c));
      txt.classList.toggle("hidden", !NEED_TEXT.includes(c) && !(txt.value));
    } }, ct("r_" + c)));
    const bg = Y().sheet(h("div", {},
      h("h3", {}, ct("cancel_title")), h("div", { class: "muted", style: "margin-top:4px" }, fmtWhen(x.iso)),
      !owner && x.late ? h("div", { class: "cab-warn" }, ct("late_note", { h: C.data.late_hours || 6 })) : null,
      h("div", { class: "muted", style: "margin-top:12px" }, ct("cancel_pick")), h("div", { class: "cab-chips" }, chips), txt,
      h("button", { class: "btn primary", style: "margin-top:14px", onclick: () => Y().safe(async () => {
        if (!code) return Y().toast(ct("need_reason"));
        if (NEED_TEXT.includes(code) && !txt.value.trim()) { txt.classList.remove("hidden"); return Y().toast(ct("need_text")); }
        const r = await Y().api("/api/cab/cancel", { iso: x.iso, code, text: txt.value, uid });
        if (r.err || r.error) return Y().toast(errText(r));
        bg.remove();
        Y().toast(owner ? ctx("cancelled_ok") : r.force_pending ? ct("cancel_force") : r.charged ? ct("cancel_late") : ct("cancel_ok"));
        load();
      }) }, ct("cancel_go")), closeBtn()));
  }

  // opts: {owner, uid, replace, who}
  function moveSheet(x, opts) {
    opts = opts || {};
    let who = opts.who || "teacher";
    const date = h("input", { type: "date", min: todayStr(), value: "" });
    const time = h("input", { type: "time", step: "300", value: x.time || "" });
    const whoRow = opts.owner ? h("div", {}, h("div", { class: "muted", style: "margin-top:12px" }, ctx("who_q")),
      h("div", { class: "seg fill" }, ["student", "teacher"].map((k) => h("button", { class: who === k ? "on" : "", onclick: (e) => {
        who = k; e.target.parentNode.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b === e.target));
      } }, ctx(k === "student" ? "who_student" : "who_teacher"))))) : null;
    const send = (allow) => Y().safe(async () => {
      if (!date.value || !time.value) return Y().toast(ct("move_pick"));
      const body = { iso: x.iso, new: date.value + "T" + time.value, uid: opts.uid, who, replace: opts.replace, allow_clash: !!allow };
      const r = await Y().api("/api/cab/move", body);
      if (r.err === "clash") return clashAsk(r.clash);
      if (r.err || r.error) return Y().toast(errText(r));
      bg.remove();
      Y().toast(opts.owner ? ctx("moved_ok") : ct("move_sent"));
      load();
    });
    const clashAsk = (name) => {
      const b2 = Y().sheet(h("div", {}, h("p", {}, ctx("clash_q", { n: name })),
        h("button", { class: "btn primary", onclick: () => { b2.remove(); send(true); } }, ctx("clash_go")), closeBtn()));
    };
    const bg = Y().sheet(h("div", {}, h("h3", {}, ct("move_title")), h("div", { class: "muted", style: "margin-top:4px" }, fmtWhen(x.iso)),
      whoRow, h("div", { class: "muted", style: "margin-top:12px" }, ct("move_pick")),
      h("div", { class: "cab-sheet-row" }, date, time),
      h("button", { class: "btn jade", style: "margin-top:14px", onclick: () => send(false) }, opts.owner ? ctx("move_btn") : ct("move_go")), closeBtn()));
  }

  function heldSheet(x) {
    const topic = h("input", { type: "text", maxlength: "120", placeholder: ctx("topic_ph") });
    const bg = Y().sheet(h("div", {}, h("h3", {}, ctx("mark")), h("div", { class: "muted", style: "margin-top:4px" }, (x.name ? x.name + " · " : "") + fmtWhen(x.iso)), topic,
      h("button", { class: "btn jade", style: "margin-top:14px", onclick: () => Y().safe(async () => {
        const r = await Y().api("/api/cab/held", { uid: x.uid, iso: x.iso, topic: topic.value });
        if (r.err || r.error) return Y().toast(errText(r));
        bg.remove(); Y().toast(ctx("held_ok")); Y().haptic("ok"); load();
      }) }, ctx("save")), closeBtn()));
  }

  // ── кабинет ученика ──
  function studentView(d) {
    const out = [balanceCard(d.balance, ct("title_my"))];
    const up = h("div", { class: "card" }, h("h3", {}, ct("next")));
    if (!d.upcoming.length) up.append(h("div", { class: "muted", style: "margin-top:8px" }, ct("no_lessons")));
    d.upcoming.forEach((x) => {
      const pend = d.pending.find((p) => p.lesson === x.iso);
      const acts = x.status === "planned" ? h("div", { class: "cab-act" },
        pend ? null : h("button", { class: "btn line", onclick: () => moveSheet(x) }, ct("btn_move")),
        h("button", { class: "btn line", onclick: () => cancelSheet(x) }, ct("btn_cancel"))) : null;
      up.append(h("div", { class: "cab-lesson" + (x.status === "cancelled" ? " off" : "") }, h("div", {},
        h("div", { class: "cab-when" }, fmtWhen(x.iso)), badges(x),
        pend ? h("div", { class: "cab-sub" }, ct("pend_move", { w: fmtWhen(pend.new) })) : null, acts)));
    });
    out.push(up);
    const tp = h("div", { class: "card" }, h("h3", {}, ct("topics")));
    if (!d.lessons.length) tp.append(h("div", { class: "muted", style: "margin-top:8px" }, ct("no_topics")));
    d.lessons.forEach((l) => tp.append(h("div", { class: "cab-hist" }, h("b", {}, "✓ " + fmtDay(l.date)), " · " + (l.topic || ct("no_topic")))));
    out.push(tp);
    if (d.log.length) out.push(h("div", { class: "card" }, h("h3", {}, ct("hist")), d.log.map(histItem)));
    return h("div", {}, out);
  }

  // ── кабинет преподавателя ──
  function lessonRow(x, inCard) {
    const acts = [];
    if (x.status === "planned" && !x.past) {
      if (x.soon) acts.push(h("button", { class: "btn jade", onclick: () => heldSheet(x) }, "✅ " + ctx("held")));
      acts.push(h("button", { class: "btn line", onclick: () => moveSheet(x, { owner: true, uid: x.uid }) }, "🔄 " + ctx("move_btn")));
      acts.push(h("button", { class: "btn line", onclick: () => cancelSheet(x, true, x.uid) }, "❌ " + ctx("cancel_btn")));
    } else if (x.status === "past") {
      acts.push(h("button", { class: "btn jade", onclick: () => heldSheet(x) }, "✅ " + ctx("held")));
      acts.push(h("button", { class: "btn line", onclick: () => cancelSheet(x, true, x.uid) }, "❌ " + ctx("cancel_btn")));
    } else if (x.status === "cancelled" && x.cancel && x.cancel.who === "student" && x.cancel.charged && x.cancel.state === "ok") {
      acts.push(h("button", { class: "btn line", onclick: () => Y().safe(async () => { const r = await Y().api("/api/cab/decide", { kind: "force", id: x.cancel.id, ok: true }); Y().toast(r.ok ? ctx("decided") : errText(r)); load(); }) }, "🆘 " + ctx("force_btn")));
    }
    return h("div", { class: "cab-lesson" + (x.status === "cancelled" ? " off" : "") }, h("div", {},
      h("div", { class: "cab-when" }, (inCard ? fmtWhen(x.iso) : x.time) + (inCard || !x.name ? "" : " · " + x.name)),
      badges(x), x.cancel && (x.cancel.code || x.cancel.text) ? h("div", { class: "cab-sub" }, reasonLabel(x.cancel.code, x.cancel.text)) : null,
      acts.length ? h("div", { class: "cab-act" }, acts) : null));
  }
  function pendingCards(p) {
    if (!p.moves.length && !p.force.length) return null;
    const card = h("div", { class: "card cab-pend" }, h("h3", {}, "⏳ " + ctx("pending")));
    p.moves.forEach((m) => card.append(h("div", { class: "cab-lesson" }, h("div", {},
      h("div", { class: "cab-when" }, m.name + " · " + ctx("req_move")), h("div", { class: "cab-sub" }, fmtWhen(m.orig) + " → " + fmtWhen(m.new)),
      m.late ? h("div", { class: "cab-warn" }, ctx("late_req", { h: 6 })) : null,
      m.clash ? h("div", { class: "cab-warn" }, ctx("clash_q", { n: m.clash })) : null,
      h("div", { class: "cab-act" },
        h("button", { class: "btn jade", onclick: () => Y().safe(async () => { await Y().api("/api/cab/decide", { kind: "move", id: m.id, ok: true }); Y().toast(ctx("decided")); load(); }) }, "✓ " + ctx("accept")),
        h("button", { class: "btn line", onclick: () => Y().safe(async () => { await Y().api("/api/cab/decide", { kind: "move", id: m.id, ok: false }); Y().toast(ctx("decided")); load(); }) }, "✗ " + ctx("reject")),
        h("button", { class: "btn line", onclick: () => moveSheet({ iso: m.orig, time: m.new.slice(11, 16) }, { owner: true, uid: m.uid, replace: m.id, who: "student" }) }, "🕐 " + ctx("other_time")))))));
    p.force.forEach((f) => card.append(h("div", { class: "cab-lesson" }, h("div", {},
      h("div", { class: "cab-when" }, f.name + " · 🆘 " + ctx("req_force")), h("div", { class: "cab-sub" }, fmtWhen(f.lesson) + (f.text ? ": " + f.text : "")),
      h("div", { class: "cab-act" },
        h("button", { class: "btn jade", onclick: () => Y().safe(async () => { await Y().api("/api/cab/decide", { kind: "force", id: f.id, ok: true }); Y().toast(ctx("decided")); load(); }) }, "🆘 " + ctx("force_btn")),
        h("button", { class: "btn line", onclick: () => Y().safe(async () => { await Y().api("/api/cab/decide", { kind: "force", id: f.id, ok: false }); Y().toast(ctx("decided")); load(); }) }, "✗ " + ctx("charged")))))));
    return card;
  }
  function weekView(d) {
    const out = [];
    const days = {};
    d.week.forEach((x) => { (days[x.date] = days[x.date] || []).push(x); });
    const day = (n) => new Date(Date.now() + 5 * 3600 * 1000 + (d.offset + n) * 86400000).toISOString().slice(0, 10);
    const nav = h("div", { class: "cab-nav" },
      h("button", { class: "btn line sm", onclick: () => { C.off -= 7; load(); } }, "←"),
      h("span", {}, fmtDay(day(0)) + " – " + fmtDay(day(6))),
      h("button", { class: "btn line sm", onclick: () => { C.off += 7; load(); } }, "→"));
    out.push(nav);
    const keys = Object.keys(days).sort();
    if (!keys.length) out.push(h("div", { class: "card muted" }, ctx("no_week")));
    keys.forEach((k) => out.push(h("div", { class: "cab-day" }, fmtDay(k)), h("div", { class: "card", style: "margin-top:6px" }, days[k].map((x) => lessonRow(x, false)))));
    return out;
  }
  function studentsView(d) {
    if (!d.students.length) return [h("div", { class: "card muted" }, ctx("no_students"))];
    return d.students.map((s) => h("button", { class: "card cab-student", onclick: () => Y().safe(async () => {
      C.card = await Y().api("/api/cab/student", { uid: s.uid }); C.view = "card"; Y().render(); window.scrollTo(0, 0);
    }) }, h("div", {}, h("b", {}, s.name), h("div", { class: "cab-sub" }, s.next ? ctx("next_l") + ": " + fmtWhen(s.next) : ""), h("div", { class: "cab-sub" }, ct("paid") + ": " + s.paid + " · " + ct("done") + ": " + s.done)),
      h("div", { class: "cab-left" + (s.left <= 1 ? " low" : "") }, s.left)));
  }
  function cardView(c) {
    const out = [h("button", { class: "linkbtn", style: "margin-top:6px", onclick: () => { C.view = "main"; C.card = null; Y().render(); } }, ctx("back")),
      h("h2", { style: "margin-top:8px" }, c.name), balanceCard(c.balance, ctx("sched"))];
    const pay = h("input", { type: "number", inputmode: "numeric", placeholder: ctx("pay_ph"), min: "1", max: "200" });
    out.push(h("div", { class: "card" }, h("h3", {}, ctx("add_pay")), h("div", { class: "cab-sheet-row" }, pay,
      h("button", { class: "btn jade sm", style: "width:auto", onclick: () => Y().safe(async () => {
        const r = await Y().api("/api/cab/pay", { uid: c.uid, n: pay.value });
        if (r.err || r.error) return Y().toast(errText(r));
        Y().toast(ctx("pay_ok")); load();
      }) }, ctx("pay_go")))));
    out.push(h("div", { class: "card" }, h("h3", {}, ct("next")), c.upcoming.length ? c.upcoming.map((x) => lessonRow(x, true)) : h("div", { class: "muted", style: "margin-top:8px" }, ct("no_lessons"))));
    if (c.past.length) out.push(h("div", { class: "card" }, h("h3", {}, ctx("lessons_h")), c.past.map((x) => lessonRow(x, true))));
    if (c.lessons.length) out.push(h("div", { class: "card" }, h("h3", {}, ct("topics")), c.lessons.map((l) => h("div", { class: "cab-hist" }, h("b", {}, "✓ " + fmtDay(l.date)), " · " + (l.topic || ct("no_topic"))))));
    if (c.payments.length) out.push(h("div", { class: "card" }, h("h3", {}, ctx("payments")), c.payments.map((p) => h("div", { class: "cab-hist" }, h("b", {}, fmtDay(p.date)), " · +" + p.lessons))));
    if (c.log.length) out.push(h("div", { class: "card" }, h("h3", {}, ct("hist")), c.log.map(histItem)));
    return out;
  }
  function ownerView(d) {
    if (C.view === "card" && C.card) return h("div", {}, cardView(C.card));
    const pend = pendingCards(d.pending);
    const seg = h("div", { class: "seg fill", style: "margin-top:14px" }, [["week", "tab_week"], ["students", "tab_students"]].map(([id, key]) =>
      h("button", { class: C.tab === id ? "on" : "", onclick: () => { C.tab = id; Y().render(); } }, ctx(key))));
    return h("div", {}, pend, seg, C.tab === "week" ? weekView(d) : studentsView(d));
  }

  function view() {
    const d = C.data;
    if (!d) return h("div", { class: "card muted", style: "text-align:center" }, "…");
    if (d.role === "student") return studentView(d);
    if (d.role === "owner") return ownerView(d);
    return h("div", { class: "card muted" }, ct("no_lessons"));
  }

  window.CAB = { enter, view, load, _state: C };
})();
